function Z=spPY(P,Y,X,t)
%HMM observation function P(Y|X,t).
%Z=PY(p,[],X,t) computes a sample Y from P(Y|X,t). If X is a NxM matrix of 
%M dimensional states, Z is a NxK vector of the samples.
%Z=PY(p,Y,X,t) computes P(Y|X,t). If X is a NxM matrix of N M-dimensional 
%states, Z is a Nx1 vector of the probabilities. "p" is a structure of 
%parameters. YM(01/2009)

%REQUIRED PARAMETERS
% P.alpha=1; %fluorescence amplitude
% P.beta=0.1; %fluorescence background
% P.gamma=1e-3; %fluorescence conversion factor
% P.n=1; %fluorescence saturation exponent
% P.k_d=10; %fluorescence saturation offset

if(isempty(Y))
  C=X(:,2);  %Ca signal
  F=P.alpha*Hill_v1(P,C)+P.beta; %fluorescence signal
  s=sqrt(P.gamma*F+P.delta^2); %fluorescence noise
  Z=F+s.*randn(size(F)); %fluorescence observation
else
  C=X(:,2);  %Ca signal
  F=P.alpha*Hill_v1(P,C)+P.beta; %fluorescence signal
  s=sqrt(P.gamma*F+P.delta^2);
  dY=(Y-F)./s;
  Z=exp(-dY.^2/2)./s/sqrt(2*pi);
end


function F = Hill_v1(P,C)
% generalized Hill model
C(C<0) = 0; F = C.^P.n./(C.^P.n+P.k_d^P.n);