function [Xr,Au]=sampleSMC(P,Y,funcPY,funcPXX,funcG)
%Sequential Monte Carlo for conditioned samples in continuous HMM.
%[Xr Au]=sampleSMC(p,Yr,@PY,@PXX,@PG) computes chain of states conditioned 
%on observations Yr in HMM specified by observation probabilities PY and 
%transition probabilities PXX. See help for sample spPY and spPXX for 
%definition of the functions setting HMM. Yr is cell-array of T 
%observations. "p" is a structure of parameters to be passed onto PY and 
%PXX, additionally defining P.iter - number of iterations in SMC - and 
%P.grid - number of points to use in stochastic "grid". Au is a vector of
%autocorrelation values. YM(01/2009)

T=length(Y);
K=P.iter; %number of iterations of MC till convergence
N=P.grid; %size of stochastic grid to use

X=cell(1,T); %form stochastic grid /pool/
for t=1:T 
  tmp=funcG(P,[],t);
  X{t}=zeros(N,length(tmp)); X{t}(1,:)=tmp;
  for k=2:N X{t}(k,:)=funcG(P,[],t); end
end

if(nargout==2) %collector for autocorrelation estimates
  n=length(X{1}(1,:)); %dimensionality of states  
  collector=zeros(K,T*n); 
end

for it=1:K-1
  Xr=sampleMC(P,X,Y,funcPY,funcPXX); %draw sample
  x=zeros(T,n); for t=1:T x(t,:)=Xr{t}; end; collector(it,:)=x(:); %Au
  
  for t=1:T
    X{t}(1,:)=Xr{t};
    for k=2:N X{t}(k,:)=funcG(P,[],t); end
  end
  if(mod(it,ceil(K/25))==0) fprintf('.'); end
end
fprintf('\n');

Xr=sampleMC(P,X,Y,funcPY,funcPXX); %draw final sample
x=zeros(T,n); for t=1:T x(t,:)=Xr{t}; end; collector(end,:)=x(:); %Au
x=xcorr(collector(:,1)); 
Au=zeros(length(x),T*n);
for k=1:T*n Au(:,k)=xcov(collector(:,k),'unbiased'); end