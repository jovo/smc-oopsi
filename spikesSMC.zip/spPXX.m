function Z=spPXX(P,X1,X0,t)
%HMM transition function P(X1|X0,t).
%Z=PXX(p,[]) computes a 1xM-dimensional sample from P(X).
%Z=PXX(p,X1) computes the probability P(X1).
%Z=PXX(p,[],X0,t) computes a 1xM-dimensional sample from P(X1|X0,t). 
%Z=PXX(p,X1,X0,t) computes P(X1|X0,t). If X1 and X0 are vectors NxM and 
%KxM matrices of N and K M-dimensional states, Z is a NxK matrix 
%P(i,j)=P(X1(i)|X0(j),t). "p" is a structure of parameters. YM(01/2009)

%REQUIRED PARAMETERS
% P.dt=0.1;  %time bin
% P.f=10; %spike generation frequency
% P.tau=0.2;  %lag of Ca reporter
% P.C0=0; %Ca background
% P.A=1; %Ca spike height
% P.eps=sqrt(0.1*P.dt); %Ca noise height

if(nargin<3 && isempty(X1))
  n=rand<1-exp(-P.f*P.dt); %spike
  C=P.C0+P.eps*randn; %base Ca
  Z=[n C];
elseif(nargin<3)
  n=X1(1); C=X1(2); %unwrap state
  dC=C-P.C0; %expected Ca-level
  Z=exp(-dC.^2/2/P.eps^2)/sqrt(2*pi)/P.eps; %Ca-Ca transition prob
  if(n==0) Z=exp(-P.f*P.dt)*Z; else Z=(1-exp(-P.f*P.dt))*Z; end %spike prob
elseif(isempty(X1))
  n=X0(1); C=X0(2); %unwrap previous point
  C=C-P.dt/P.tau*(C-P.C0)+P.A*n+P.eps*randn; %new Ca
  n=rand<1-exp(-P.f*P.dt); %new spike  
  Z=[n C];
else
  n0=X0(:,1); C0=X0(:,2); M=length(C0);
  n1=X1(:,1); C1=X1(:,2); N=length(C1);

  C0=C0-P.dt/P.tau*(C0-P.C0)+P.A*n0; %expected Ca-level
  A=repmat(reshape(C1(:),N,1),[1,M,1]);
  B=repmat(reshape(C0(:),1,M),[N,1,1]);
  Z=exp(-(A-B).^2/2/P.eps^2)/sqrt(2*pi)/P.eps; %Ca-Ca transition prob

  z=repmat(exp(-P.f*P.dt),N,1); z(n1>0)=1-z(n1>0); %n1 generation prob
  Z=Z.*repmat(z(:),[1 M]);
end