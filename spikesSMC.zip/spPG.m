function Z=PG(P,X,t)
%Z=PG(p,X,t)
%Grid function rho(X,t). If X is empty, returns a sample of X from 
%rho(X,t). In case X is a vector, produces a vector of P_i=rho(X_i,t). "p"
%is a structure of parameters.
if(isempty(X))
  n=rand<1-exp(-P.f*P.dt);
  F=(P.F{t}-P.beta)/P.alpha;
  C=AHill_v1(P,F);
  s=sqrt(P.gamma*F);
  s=max(P.invs,2*s*C/(P.n*F*(1-F))); %Jacobian noise conversion
  Z=[n C+randn*s]';
else
  F=(P.F{t}-P.beta)/P.alpha;
  C=AHill_v1(P,F);
  s=sqrt(P.gamma*F);
  s=max(P.invs,2*s*C/(P.n*F*(1-F))); %Jacobian noise conversion  
  C0=X(:,2); %Ca levels
  Z=exp(-(C0-C).^2/2/s.^2)/sqrt(2*pi)/s;
  
  n=X(:,1); %spikes
  z=repmat(exp(-P.f*P.dt),size(n)); z(n>0)=1-z(n>0); %n generation prob
  Z=Z.*z;  
end


function C = AHill_v1(P,F)
% generalized hill model, inverse
C = (F./(1-F)).^(1/P.n)*P.k_d; C(C<0)  = 0;
