function Enew = smc_em_bern_mstep_v1(Sim,S,E)

Enew = E;
RateParams=E.k*1.5;

if Sim.M>0
    RateParams=[RateParams; E.omega];
end

min_RateParams = fminunc(@f_bkos,RateParams);

function f = f_bkos(RateParams)

f=-sum(sum(S.w_b(S.I).*(S.p(S.I))));
f=f-sum(sum(S.w_b(~S.I).*(S.p(~S.I))));

end %function f = f_bkos(RateParams)

Enew.k = min_RateParams(1:end-Sim.M);
if Sim.M>0
    Enew.omega=min_RateParams(end-Sim.M+1:end);
end

end %function Enew = smc_em_bern_mstep_v1(Sim,S,E)

