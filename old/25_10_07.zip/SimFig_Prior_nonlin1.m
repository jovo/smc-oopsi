% this m-file generates the data and then plots the fig demonstrating
% how stonger priors make the sampling more efficient 
% observations. It generates the following:
%
% Sim:  simulation parameters
% P:    parameters of "real" neuron
% R:    "real" neuron data                  (smc_em_bern_real_exp)
% S:    simulation states for both samplers (smc_em_bern_FoBaMo)
% M:    moments for both samplers           (smc_em_bern_FoBaMo)
% fig:  see fig file for details            

%% start function
clear; clc;

[Sim P] = InitializeStuff;

%% set simulation parameters
Sim.Nsec    = 1.5;              %# of sec
Sim.freq    = 8;               %relative frequency of observations
Sim.StimDim = 1;                        %# of stimulus dimensions

P.k         = 1;                        %bias term
P.gamma     = 1e-4;                     %var gainh
P.zeta      = .1e-4;                    %var offset

% make code prettier
Sim.T       = round(Sim.Nsec/Sim.dt);   %total # of steps (round deals with numerical error)
rem         = mod(Sim.T,Sim.freq);      %remainder
if rem~=0
    Sim.T=Sim.T-rem;                    %fix number of steps
end
Sim.T_o     = round(Sim.T/Sim.freq);    %number of observations (round deals with numerical error)
Sim.tvec    = Sim.dt:Sim.dt:Sim.Nsec-Sim.dt*rem;%time vector


%% get "real" data

R.n         = zeros(1,Sim.T);   %spike times
R.C         = P.C_0*ones(1,Sim.T);      %initialize calcium
epsilon_c   = P.sigma_c*sqrt(Sim.dt)*randn(1,Sim.T);%generate noise on calcium
spt         = [35 65 72]+100;%forced spike times
R.n(spt)    = 1;                %force spikes

for t=2:Sim.T                   %update calcium
    R.C(t)  = (1-P.a)*R.C(t-1) + P.Aeff*R.n(t) + P.a*P.C_0 + epsilon_c(t);
end
F_mu        = GenHill_v2(P,R.C);        %compute E[F_t]
F_var       = P.gamma*F_mu + P.zeta;    %compute V[F_t]
R.F         = F_mu+sqrt(F_var).*randn(1,Sim.T);%add noise to observations
R.F(R.F<0)  = eps;                      %observations must be non-negative

priors      = [1 5 5];

%% do EM recursions
for n=1:3                       %for all 3 different priors
    Sim.x       = ones(Sim.StimDim,Sim.T);%extize stimulus
    if n==2, Sim.x(spt(1):spt(end)) = priors(n);    %add appropriate pulese
    elseif n==3, Sim.x(spt)         = priors(n);
    end
    [S(n) M(n)] = smc_em_bern_FoBaMo_v5(Sim,R,P);%do forward-backward and get moments
end

%% make a fig
figure(4), clf,
set(gcf, 'color', 'w');

%let O be only observations at sample times
O       = R.F.*repmat([NaN*ones(1,Sim.freq-1) 1],1,Sim.T_o);
Onan    = find(~isfinite(O));
Oind    = find(isfinite(O));
O(Onan) = [];

%limits of x-axis
xs      = [0 Sim.Nsec-2*(Sim.dt*Sim.freq)];
xticks  = Sim.tvec(1)+Sim.dt:Sim.dt*40:Sim.tvec(end);
xticks  = xticks-xticks(1);

%axes
priAX   = [xs 0 max(priors)];   %axes for prior plots
parAX   = [xs 0 1];             %axes for particle plots
OAX     = [xs/Sim.dt 0 1];      %axes for observation plots

%get min and max of calcium for normalizing the plots
omin    = min(O);
omax    = max(O);

%define colors
gray=[0.75 0.75 0.75];          %define gray
col=[0 0 1; 0 .5 0];            %define colors for mean
ccol=col+.8; ccol(ccol>1)=1;    %define colors for std

%subfig positions
l1   = .225;                    %left side of fig
w   = .21;                      %width
ws  = .05;                      %width spacer

b1  = .15;                      %bottom
h   = .222;                     %height
hs  = .05;                      %height space
b2  = b1+h+hs;                  %bottom of 2nd row
b3  = b2+h+hs;                  %bottom of 3rd row

%other stuff
tl  = [.04 .25];                %tick length [2d, 3d]
yfs = 15;                       %ylabel font size
xfs = 15;                       %xlabel font size
tfs = 15;                       %title font size
sw  = 2;                        %spike width

% make plots
for i=1:3

    % plot prior
    subplot('Position',[l1+(w+ws)*(i-1) b3 w h])            %subplot('Position',[left bottom width height])  subplot(3,3,i) %
    Sim.x       = ones(Sim.T,1);                            %extize stimulus
    if i==2, Sim.x(spt(1):spt(end)) = priors(i);                                %add appropriate pulese
    elseif i==3, Sim.x(spt)         = priors(i);
    end
    stem(Sim.tvec,Sim.x,'color','k','marker','none','linewidth',sw)
    axis(priAX)
    set(gca,'YTickLabel',[],'XTickLabel',[],'box','off')
    if i==1                                                 %top left plot
        ylab=ylabel({'External';'Stimulus'});               %gets ylabel
        set(ylab,'Rotation',0,'HorizontalAlignment','right','verticalalignment','middle','fontsize',yfs,'color','k')
    end                                                     %the other prior figs get no ylabel
    set(gca,'YTick',priors(1:2),'YTickLabel',[],'TickLength',tl,'XTick',xticks)
    if i==1                                                 %label the columns
        title({'None'},'fontsize',tfs)
        set(gca, 'YTickLabel',priors)
    elseif i==2
        title({'Coarse'},'fontsize',tfs)
    elseif i==3
        title({'Fine'},'fontsize',tfs)
    end

    % plot observations
    subplot('Position',[l1+(w+ws)*(i-1) b2 w h])            %subplot('Position',[left bottom width height]) subplot(3,3,i+Ncols) %
    cla, hold on
    plot(Oind,(O-omin)/(omax-omin),'.k','LineWidth',1,'markersize',10)
    set(gca,'YTick',[0:.5:1],'YTickLabel',[],'TickLength',tl,'box','off')
    axis(OAX)
    if i==1                                                 %left most plot gets ylabel
        ylab=ylabel('Observations');
        set(ylab,'Rotation',0,'HorizontalAlignment','right','verticalalignment','middle','fontsize',yfs,'color','k')
    end
    set(gca,'XTick',[0:40:240],'XTickLabel',[])

    % plot spike inference
    subplot('Position',[l1+(w+ws)*(i-1) b1 w h])            %subplot(3,3,i+Ncols*2)
    cla, hold on
    stem(Sim.tvec,R.n,'Marker','none','Color',gray,'LineWidth',sw)
    BarVar=M(i).nbar+M(i).nvar;
    BarVar(BarVar>1)=1;
    stem(Sim.tvec,BarVar,'Marker','none','Color',ccol(2,:),'LineWidth',sw)
    stem(Sim.tvec,M(i).nbar,'Marker','none','Color',col(2,:),'LineWidth',sw)
    axis([parAX])

    set(gca,'YTick',[0 .5 1], 'YTickLabel',[],'XTick',xticks,'TickLength',tl)
    if i==1
        ylab=ylabel({'Inferred';'Spikes'});
        set(ylab,'Rotation',0,'HorizontalAlignment','right','verticalalignment','middle','color',col(2,:),'fontsize',yfs)
    end
    xlab=xlabel('Time (sec)');
    set(xlab,'fontsize',xfs);
end

text('String','Prior',...
    'Position',[-4.122 3.75 17.32],...
    'FontSize',tfs);

% print to (color) eps
fig=figure(4);
wh=[7 3];   %width and height
set(fig,'PaperPosition',[0 11-wh(2) wh]);
print -depsc C:\D\Research\liam\SMC_EM_GLM\prior