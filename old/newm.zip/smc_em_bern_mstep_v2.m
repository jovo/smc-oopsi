function Enew = smc_em_bern_mstep_v2(Sim,S,M,E)
% this function generates a new set of parameters 'Enew'
% input:
%   Sim:    simulation parameters
%   R:      real data
%   S:      simulation results
%   M:      moments and sufficient stats
%   E:      old parameter estimates

Enew = E;

if Sim.Rparams == true
    %%MLE for spike rate parameters: baseline (b), linear filter (k), and spike
    %%history weights (omega)
    fprintf('\nestimating spike rate params\n')
    RateParams=E.k;
    sp      = S.n==1;                   %find (particles,time step) pairs that spike
    nosp    = S.n==0;                   %don't spike
    x       = repmat(Sim.x,1,Sim.N);    %generate matrix for gradinent
    zeroy   = zeros(Sim.N,Sim.T);       %make matrix of zeros for evaluating lik

    if Sim.M>0                          %if spike history terms are present
        RateParams=[RateParams; E.omega];%also estimate omega
        for i=1:Sim.M                   %and modify stimulus matrix for gradient
            x(Sim.StimDim+i,:)=reshape(S.h(:,:,i),1,Sim.N*Sim.T);
        end
    end

    options = optimset('Display','off','GradObj','off'); %use gradient
    bko     = fminunc(@f_bko,RateParams,options);%find MLE
    Enew.k  = bko(1:end-Sim.M);         %set new parameter estimes
    if Sim.M>0                          %for omega too
        Enew.omega = bko(end-Sim.M+1:end);
    end
end


%% MLE for calcium parameters
if Sim.Cparams == true
    fprintf('estimating calcium parammeters\n')
    ve_x        = quadprog(M.Q, M.L,[],[],[],[],[0 0 0],[inf inf inf],[1/E.tau_c E.A E.C_0/E.tau_c]);
    Enew.tau_c  = 1/ve_x(1);
    Enew.A      = ve_x(2);
    Enew.C_0    = ve_x(3)/ve_x(1);
%     Enew.sigma_c= sqrt(-(0.5*ve_x'*M.Q*ve_x + M.L'*ve_x))/(Sim.T*Sim.dt);
end

% % %% MLE for spike history parameters
% % for m=1:Sim.M
% %     Enew.sigma_h(m)= sum(M.v{m})/Sim.T;
% % end
%
% %% MLE for observation parameters
% O       = R.O.*repmat([NaN*ones(1,Sim.freq-1) 1],1,Sim.T_o);
% Oind    = find(~isnan(O));
% Enew.sigma_o = sqrt(sum(sum(S.w_b(:,Oind).*(repmat(O(Oind),Sim.N,1)-S.C(:,Oind)).^2)/Sim.T));


%% this is old code
%%%%%%%% maximize alpha and beta
% Ps=S.w_b(:,2:end);
% Ps=sqrt(Ps(:));
% ns=S.n(:,2:end);
% ns=ns(:);
% J=[Ps'.*repmat(R.C(2:end)*Sim.dt,1,Sim.N); -Ps'.*ns']*[Ps'.*repmat(R.C(2:end)*Sim.dt,1,Sim.N); -Ps'.*ns']';
% 
% Ps=S.w_b(:,2:end)';
% Ps=Ps(:);
% ns=S.n(:,2:end)';
% ns=ns(:);
% f=[repmat(R.C(2:end)*Sim.dt,1,Sim.N); -ns']*(repmat(R.C(2:end)-R.C(1:end-1),1,Sim.N)'.*Ps);
% 
% [minab,fval,exitflag,output,lambda] = quadprog(J, f,[],[],[],[],[0 -inf],[],[1 1]);
% Enew.tau_c=1/minab(1);
% Enew.beta=minab(2);
% 
% %%%%%%%% maximize sigma
% DelCs=repmat(R.C(2:end)-R.C(1:end-1)*exp(-minab(1)*Sim.dt),1,Sim.N);
% DelCs=DelCs(:);
% Enew.sigma_c=sqrt(sum(Ps.*(DelCs-minab(2)*ns).^2/Sim.dt)/sum(Ps(:)));
% 
    function [lik dlik]= f_bko(RateParams)          %get lik and grad

        xk      = RateParams(1:end-Sim.M)'*Sim.x;   %filtered stimulus
        hs      = zeroy;                            %incorporate spike history terms
        for l=1:Sim.M
            hs  = hs+RateParams(end-Sim.M+l)*S.h(:,:,l);
        end
        s       = repmat(xk,Sim.N,1) + hs;

        f_kdt   = exp(s)*Sim.dt;    %shorthand
        lik     = -sum(S.w_b(sp).*log(1-exp(-f_kdt(sp))))... %liklihood
            +sum(S.w_b(nosp).*f_kdt(nosp));

        if nargout > 1                              %if gradobj=on
            ef      = exp(f_kdt);                   %shorthand
            dlik      = x(:,sp)*(S.w_b(sp).*f_kdt(sp)./( ef(sp)-1))... %gradient of lik
                -x(:,nosp)*(S.w_b(nosp).*f_kdt(nosp));
        end
    end %function f_bko

end
