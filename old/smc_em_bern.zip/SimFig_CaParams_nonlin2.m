% this file sets the parameters and does the simulation for making the
% m-step fig.  stimulus is multidimensional gaussian noise. It generates the following:
%
% Sim:  simulation parameters
% P:    parameters of "real" neuron
% R:    "real" neuron data
% S:    simulation states for both samplers
% M:    moments for both samplers
% E:    parameter estimates (not used)
% fig:  see fig file for details

%% start function
clear; clc; close all

[Sim P] = InitializeStuff;

% set simulation parameters
Sim.M       = 1;                    %# spike history terms
Sim.StimDim = 1;                    %stimulus dimensionality
Sim.Mstep   = true;                 %go M-step
Sim.MaxIter = 25;                   %max # of iters
Sim.Ntrials = 5;
Sim.Cparams = true;
Sim.Rparams = false;
Sim.SpikHis = false;

P.k         = 2;                  %linear kernel
P.omega     = -P.k;                 %spike history weight
P.tau_h     = .025;                 %gecay rate for spike history terms
P.tau_c     = 0.5;                  %gecay rate of calcium
P.A         = 0.1;                  %jump size of calcium after spike
P.C_0       = 0.01;                 %baseline calcium
P.C_init    = 1.2;
P.gamma     = 1e-5;                 %var gainh
P.zeta      = 1e-4;                 %var offset
nSpikes     = 50.*2.^[0:4];
figure(2), clf, hold on, stem([P.tau_c; P.A; P.C_0; P.sigma_c],'r','linewidth',2), 

%%
for nn = 1:length(nSpikes)
    Sim.Nsec    = 180;                       %# of sec
    Sim.T       = round(Sim.Nsec/Sim.dt);   %total # of steps (round deals with numerical error)
    Sim.T_o     = round(Sim.T/Sim.freq);    %number of observations (round deals with numerical error)
    Sim.x       = ones(1,Sim.T);            %make a constant stim for baseline firing rate
    for k=1:Sim.Ntrials
        R       = smc_em_bern_real_exp_v5(Sim,P);
        spikes  = find(R.n,nSpikes(nn));
        Sim.T   = spikes(end);
        rem     = mod(Sim.T,Sim.freq);      %remainder
        if rem~=0
            Sim.T=Sim.T-rem;                    %fix number of steps
        end
        Sim.x(:,Sim.T+1:end)=[];
        R.n(Sim.T+1:end)    =[];
        R.C(Sim.T+1:end)    =[];
        R.F(Sim.T+1:end)    =[];
        R.p(Sim.T+1:end)    =[];
        R.h(Sim.T+1:end)    =[];

        fprintf('\n\nTrial #%g, # spikes=%g\n',k,sum(R.n))

        EI          = P;
        EI.tau_c    = 2*EI.tau_c;
        EI.A        = 2*EI.A;
        EI.C_0      = 2*EI.C_0;
        EI.sigma_c  = 10*P.sigma_c;
        Enew        = EI;
        i           = 0;                    %iteration number
        Enew.lik    = inf;
        minlik      = inf;
        minliki     = i;

        ErrNew      = norm([Enew.tau_c; Enew.A; Enew.C_0; Enew.sigma_c]-[P.tau_c; P.A; P.C_0; P.sigma_c]);
        ErrOld      = ErrNew;
        dtheta      = inf;
        Sim.conv    = false;
        while Sim.conv==false;
            [S M]   = smc_em_bern_FoBaMo_v5(Sim,R,Enew);
            Eold    = Enew;
            Enew    = smc_em_bern_mstep_v2(Sim,S,M,Enew);
            if Enew.lik<minlik
                minlik=Enew.lik;
                minliki=i;
            end
            i       = i+1;
            
            ErrOld = ErrNew;
            ErrNew  = norm([Enew.tau_c; Enew.A; Enew.C_0; Enew.sigma_c]-[P.tau_c; P.A; P.C_0; P.sigma_c]);
            dtheta  = norm([Enew.tau_c; Enew.A; Enew.C_0]-[Eold.tau_c; Eold.A; Eold.C_0])/norm([Eold.tau_c; Eold.A; Eold.C_0; Enew.sigma_c]);

            fprintf('\nIteration #%g,  N error=%g, lik=%g, dlik=%g, derr=%g, dtheta=%g\n',i,ErrNew,Enew.lik,Enew.lik-Eold.lik,ErrOld-ErrNew,dtheta)
            fprintf('\ntau_c: est=%g, true=%g',Enew.tau_c,P.tau_c)
            fprintf('\nA: est=%g, true=%g',Enew.A,P.A)
            fprintf('\nC_0: est=%g, true=%g',Enew.C_0,P.C_0)
            fprintf('\nsigma_c: est=%g, true=%g',Enew.sigma_c,P.sigma_c)
            if i>Sim.MaxIter || dtheta<.003 %|| i>minliki+3
                Sim.conv=true;
                if ErrNew>ErrOld
                    E(nn,k)=Eold;
                else
                    E(nn,k)=Enew;
                end
                figure(2), plot([E(nn,k).tau_c; E(nn,k).A; E(nn,k).C_0],'b','linewidth',2), drawnow
                save('Ca_params2','Sim','R','P','M','E')
            end
        end
    end
end