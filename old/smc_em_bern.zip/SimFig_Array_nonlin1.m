% this m-file generates the data and then plots the fig demonstrating how
% backwards sampler works for different intermittencies and noise on
% observations. It generates the following:
%
% Sim:  simulation parameters
% P:    parameters of "real" neuron
% R:    "real" neuron data                  
% S:    simulation states for both samplers 
% M:    moments for both samplers           
% fig:  see fig file for details            

%% start function
clear; clc;

[Sim P] = InitializeStuff;

% set figure specific parameters
Sim.Nsec    = 1.44;                      %# of sec
Sim.StimDim = 1;                        %# of stimulus dimensions
Sim.M       = 0;                        %number of spike history terms
Sim.pf      = 1;                        %not vanilla particle filtering
Sim.T       = round(Sim.Nsec/Sim.dt);   %total # of steps (round deals with numerical error)
Sim.x       = ones(1,Sim.T);            %make 1D fixed input

% get "real" data
R.n         = zeros(1,Sim.T);           %spike times
R.C         = P.C_init*ones(1,Sim.T);      %initialize calcium
epsilon_c   = P.sigma_c*sqrt(Sim.dt)*randn(1,Sim.T);%generate noise on calcium
spt         = [83 121 155];             %forced spike times
R.n(spt)    = 1;                        %force spikes

for t=2:Sim.T                           %update calcium
    R.C(t)  = (1-P.a)*R.C(t-1) + P.A*R.n(t) + P.a*P.C_0 + epsilon_c(t);
end
F_mu        = P.alpha*Hill_v1(P,R.C)+P.beta;        %compute E[F_t]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A.freq      = 2.^[1:4];           %vector of # of times between each observation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gamma       = 1e-5;                     %var gainh
zeta        = 1e-4;                     %var offset

%set k such that expected number of spikes is the number of actual spikes
P.k         = log(-log(1-length(spt)*Sim.dt*Sim.Nsec)/Sim.dt);

% do EM recursions
for i=1:length(A.freq)                                          %loop over different amounts of noise
    for j=1:length(A.freq)                                      %loop over different sampling frequencies
        fprintf('\n\nvar=%d, freq=%d\n',A.freq(i),A.freq(j));
        P.gamma         = A.freq(i)*gamma/2;
        P.zeta          = A.freq(i)*zeta/2;
        F_var           = P.gamma*Hill_v1(P,R.C)+P.zeta;                %compute V[F_t]
        R.F             = F_mu+sqrt(F_var).*randn(1,Sim.T);     %add noise to observations
        Sim.freq        = A.freq(j);                            %set sampling frequency
        Sim.T_o         = Sim.T/Sim.freq;                       %fix # of observations
        [S(i,j) M(i,j)] = smc_em_bern_FoBaMo_v5(Sim,R,P);       %do forward-backward and get moments
        Os{i,j} = R.F;                                          %store the observations so that they may be plotted
    end
end

%% make a fig
figure(3), clf, cla                     %clear the fig
set(gcf, 'color', 'w');                 %make background color white

Nrows   = length(A.freq);               %rows are different observation noise
Ncols   = length(A.freq);               %columns are different sampling frequencies

gray    = [0.75 0.75 0.75];             %define gray
col     = [0 0 1; 0 .5 0; 1 0 0];       %define colors for mean
ccol    = col+.8; ccol(ccol>1)=1;       %define colors for std
ind     = Sim.T:-1:1;                   %inverse indices for 'fill' function

tl      = [.03 0.25];                   %tick length
yfs     = 16;                           %ylabel font size
xfs     = 14;                           %xlabel font size
tfs     = 14;                           %other text font size
sw      = 2;                            %spike width
lw      = 2;                            %line width

xmin    = 42;                           %find index of first time step
xmax    = 185;                          %find index of last time step
Sim.tvec= 0:Sim.dt:Sim.Nsec-Sim.dt; %time vector

xs      = [Sim.tvec(xmin) Sim.tvec(xmax)];%the limits of x-axis on which to plot things
xind    = xmin:xmax;                    %indices of x-axis
xticks  = Sim.tvec(1)+Sim.dt:Sim.dt*40:Sim.tvec(end);
xticks  = xticks-xticks(1);

for i=1:Ncols                           %find effective min and max for each simulation
    for n=1:Nrows
        cmin(i,n)   = min(M(n,i).Cbar(xind)-sqrt(M(n,i).Cvar(xind)));
        cmax(i,n)   = max(M(n,i).Cbar(xind)+sqrt(M(n,i).Cvar(xind)));
    end
end
cmin=min(cmin(:));%use cmin and cmax to normalize...
cmax=max(cmax(:));    %all the calcium plots to go between 0 and 1

% make fig
kk=0;
for i=1:Ncols
    Sim.freq    = A.freq(i);                                                            %set frequency
    Sim.T_o     = Sim.T/Sim.freq;                                                       %number of observations
    for n=1:Nrows
        clear O Onan Oind Ointer                                                        %let O be only observations at sample times
        O           = Os{n,i}.*repmat([NaN*ones(1,Sim.freq-1) 1],1,Sim.T_o);
        ONaNind     = find(~isfinite(O));
        Oind        = find(isfinite(O));
        O(ONaNind)  = [];

        j=(Nrows-n)*(Ncols)+i;                                                          %index of subplot
        subplot(Nrows,Ncols,j), cla, hold on
%         title(sum(M(n,i).nbar))

        % plot O stuff
        plot(Oind*Sim.dt,(O-min(O))/(max(O)-min(O))+2,'.k','LineWidth',1,'markersize',7)      %plot observations
%         plot(Oind*Sim.dt,(InvGenHill(P,O)-cmin)/(cmax-cmin)+2,'.k','LineWidth',1,'markersize',7)      %plot observations
%         plot(Sim.tvec,(R.C-cmin)/(cmax-cmin)+2,'color',gray,'LineWidth',1)
        plot(Sim.tvec,2*ones(size(Sim.tvec)),'k')                                         %plot a line dividing calcium and spikes

        % plot [Ca++] stuff
        ptiles = GetPercentiles([.25 .75],S(n,i).w_b,S(n,i).C);
        hfill=fill([Sim.tvec Sim.tvec(ind)],([ptiles(1,:) ptiles(2,ind)]-cmin)/(cmax-cmin)+1,ccol(2,:));
        set(hfill,'edgecolor',ccol(2,:))
        plot(Sim.tvec,(M(n,i).Cbar-cmin)/(cmax-cmin)+1,'linewidth',2,'color',col(2,:))
        plot(Sim.tvec,(R.C-cmin)/(cmax-cmin)+1,'color',gray,'LineWidth',1)
        plot(Sim.tvec,ones(size(Sim.tvec)),'k')        
        
        % plot spike stuff
        stem(Sim.tvec,R.n,'Marker','none','Color',gray,'LineWidth',sw)                  %plot actual spikes
        BarVar=M(n,i).nbar+M(n,i).nvar;                                                 %make sure var of spikes doesn't get larger than 1
        BarVar(BarVar>1)=1;
        stem(Sim.tvec,BarVar,'Marker','none','Color',ccol(2,:),'LineWidth',sw)          %plot variance of spikes
        stem(Sim.tvec,M(n,i).nbar,'Marker','none','Color',col(2,:),'LineWidth',sw)      %plot mean of spikes
        axis([xs 0 3])

        % set labels and such
        set(gca,'TickLength',tl,'XTick',xticks,'YTick',[0:.5:2])
        set(gca,'XTickLabel',[],'YTickLabel',[]),

        if n==1,
%             xlab=[num2str(1/(A.freq(i)*Sim.dt)) ' Hz'];
            xlab=[num2str(A.freq(i)*5) ' ms'];
            set(get(gca,'XLabel'),'String',xlab,'fontsize',xfs),
            set(gca,'TickLength',tl,'XTick',xticks,'XTickLabel',[0 xticks])
        end
        if i==1,
            ylab=[num2str(A.freq(n)/A.freq(1)) ' sigma_o^2'];
            set(get(gca,'YLabel'),'String',texlabel(ylab),'fontsize',yfs,'color','k',...
                'Rotation',0,'HorizontalAlignment','right','verticalalignment','middle')
        end
        box on
        kk=kk+1;
        Nsp(kk)=sum(M(n,i).nbar);
    end
end

% add some stuff to make fig pretty
annotation('arrow',[0.03639 0.03639],[0.4084 0.628],'linewidth',2);   	%yaxis arrow  %[x(1) x(2)], [y(1) y(2)]
annotation('arrow',[0.4156 0.6219],[0.03848 0.03848],'linewidth',1.5);    %xaxis arrow


text('Position',[-3.145 -0.8 17.32],...%[-2.355 -12.33 17.32],...
    'Interpreter','tex',...
    'String','Increasing Observation Noise',...
    'FontSize',tfs,...
    'FontName','Helvetica',...
    'Rotation',90,...
    'HorizontalAlignment','right',...
    'verticalalignment','middle')

text('Interpreter','tex',...
    'String','Increasing Intermittency',...
    'Position',[-1.5  -14.32 17.32],...
    'FontSize',tfs,...
    'FontName','Helvetica',...
    'Rotation',0)

annotation('arrow',[0.3351 0.2865],[0.7053 0.7665]);
annotation('arrow',[0.5423 0.4937],[0.7053 0.7665]);
annotation('arrow',[0.7495 0.7009],[0.7053 0.7665]);

annotation('arrow',[0.3351 0.2865],[0.4861 0.5473]);
annotation('arrow',[0.5423 0.4937],[0.4861 0.5473]);
annotation('arrow',[0.7495 0.7009],[0.4861 0.5473]);

annotation('arrow',[0.3351 0.2865],[0.2669 0.3281]);
annotation('arrow',[0.5423 0.4937],[0.2669 0.3281]);
annotation('arrow',[0.7495 0.7009],[0.2669 0.3281]);

% print fig to epsc
fig=figure(3);
bgr=[7 7];
set(fig,'PaperPosition',[0 11-bgr(2) bgr]);
print -depsc C:\D\Research\liam\SMC_EM_GLM\array