% this m-file generates the data and then plots the fig demonstrating
% how stonger priors make the sampling more efficient
% observations. It generates the following:
%
% Sim:  simulation parameters
% P:    parameters of "real" neuron
% R:    "real" neuron data                  (smc_em_bern_real_exp)
% S:    simulation states for both samplers (smc_em_bern_FoBaMo)
% M:    moments for both samplers           (smc_em_bern_FoBaMo)
% fig:  see fig file for details

%% start function
clear; clc;

[Sim P] = InitializeStuff;

%% set simulation parameters
Sim.Nsec    = 10;                        %# of sec
Sim.T       = round(Sim.Nsec/Sim.dt);   %total # of steps (round deals with numerical error)
rem         = mod(Sim.T,Sim.freq);      %remainder
if rem~=0
    Sim.T=Sim.T-rem;                    %fix number of steps
end
Sim.T_o     = round(Sim.T/Sim.freq);    %number of observations (round deals with numerical error)
Sim.tvec    = Sim.dt:Sim.dt:Sim.Nsec-Sim.dt*rem;%time vector
Sim.M       = 1;
Sim.StimDim = 1;
Sim.x       = ones(Sim.StimDim,Sim.T);  %generate stimulus

epsilon_c   = P.sigma_c*sqrt(Sim.dt)*randn(1,Sim.T);%generate noise on calcium
ISI         = [200 50];
randF       = randn(1,Sim.T);
P.k         = 3;
P.A         = .3;
P.tau_c     = 1;
P.omega     = -8;
P.tau_h     = .01;                %decay rate for spike history terms
P.zeta      = 1e-4;
P.gamma     = 1e-5;
P.alpha     = 1;
P.beta      = 0;
P.C_0       = .5;
P.C_init    = .5;
P.a         = Sim.dt/P.tau_c;


% R           = smc_em_bern_real_exp_v5(Sim,P);
slowrate    = 200;
ISI         = round(slowrate.*0.7.^[0:5]);
endrate     = 0;
len         = length(ISI);
spt         = 0;
for i=1:len
    spt         = [spt [max(spt):ISI(i):3*ISI(i)+max(spt)]];
end
spt(spt<200)= [];
spt         = [spt max(spt):ISI(len):Sim.T];
% spt(1:5)   = [200:200:1000];
R.n         = zeros(1,Sim.T);           %spike times
R.C         = P.C_0*ones(1,Sim.T);      %initialize calcium
R.n(spt)    = 1;                        %force spikes
for t=2:Sim.T                           %update calcium
    R.C(t)  = (1-P.a)*R.C(t-1) + P.A*R.n(t) + P.a*P.C_0 + epsilon_c(t);
end
F_mu        = P.alpha*Hill_v1(P,R.C)+P.beta;        %compute E[F_t]
F_var       = P.gamma*Hill_v1(P,R.C)+P.zeta;    %compute V[F_t]
R.F      = F_mu+sqrt(F_var).*randF;%add noise to observations
R.F(R.F<0)  = eps;                      %observations must be non-negative

figure(1), clf, hold on, 
O           = R.F.*repmat([NaN*ones(1,Sim.freq-1) 1],1,Sim.T_o);%let O be only observations at sample times
ONaNind     = find(~isfinite(O));
Oind        = find(isfinite(O));
O(ONaNind)  = [];
finv        = ((P.k_d.*(P.beta-O))./(O-P.beta-P.alpha)).^(1/P.n);
plot(Sim.tvec,R.C,'r','linewidth',2), 
plot(Oind*Sim.dt,finv,'og','linewidth',2)
figure(2), clf, hold on, plot(Oind*Sim.dt,O,'k','linewidth',2)

[S M]       = smc_em_bern_FoBaMo_v5(Sim,R,P);%do forward-backward and get moments
% plot(Sim.tvec,S.C','b')
plot(Sim.tvec,R.C,'r','linewidth',2), 
plot(Sim.tvec,M.Cbar,'k','linewidth',2)
plot(Sim.tvec,sum(S.w_f.*S.C,1),'m','linewidth',2)

%% make a fig
figure(5), clf,

%let O be only observations at sample times
O       = R.F.*repmat([NaN*ones(1,Sim.freq-1) 1],1,Sim.T_o);
Onan    = find(~isfinite(O));
Oind    = find(isfinite(O));
O(Onan) = [];

%define colors
gray=[0.75 0.75 0.75];          %define gray
col=[0 0 1; 0 .5 0; 1 0 0; 0 1 1; 1 0 1; 1 .5 0; 1 .5 1];%define colors for mean
ccol=col+.8; ccol(ccol>1)=1;    %define colors for std
ind     = Sim.T:-1:1;                   %inverse indices for 'fill' function
xmin    = Oind(3);
xmax    = Oind(end-2);
xind    = xmin:xmax;
xs      = [Sim.tvec(xmin) Sim.tvec(xmax)];
cmax    = max(R.C(xind));
cmin    = min(R.C(xind));

%other stuff
tl  = [.04 .25];                %tick length [2d, 3d]
yfs = 15;                       %ylabel font size
xfs = 15;                       %xlabel font size
tfs = 15;                       %title font size
lfs = 15;                       %label font size
sw  = 2;                        %spike width
lw  = 2;                        %line width

% plot real n, C, F
%fluorescence
subplot(3,1,1), hold on, %title(num2str(sum(R.n)))
plot(Sim.tvec,(R.F-P.beta)/P.alpha,'k','LineWidth',lw)
axis([xs 0 1])
% if k==1,
    ylab=ylabel([{'$\, \, \, \,  F_t$'}; {'(a.u.)'}]);
    set(ylab,'Rotation',0,'HorizontalAlignment','right','verticalalignment','middle','color','k','fontsize',yfs,'Interpreter','latex')
% end
set(gca,'YTick',[0 0.5 1],'YTickLabel',[{'0'}; {''}; {'1'}])
set(gca,'XTick',[])

%calcium
subplot(3,1,2), hold on, %title(num2str(sum(R.n)))
ptiles = GetPercentiles([.25 .75],S.w_b,S.C);
hfill=fill([Sim.tvec Sim.tvec(ind)],([ptiles(1,:) ptiles(2,ind)]-cmin)/(cmax-cmin),ccol(2,:));
set(hfill,'edgecolor',ccol(2,:))
plot(Sim.tvec,(R.C-cmin)/(cmax-cmin),'color',gray,'LineWidth',lw)
plot(Sim.tvec,(M.Cbar-cmin)/(cmax-cmin),'color',col(2,:),'LineWidth',lw)
%     plot(Sim.tvec,(ML.Cbar-P.C_0-cmin)/(cmax-cmin),'color',ccol(3,:),'LineWidth',1)
% plot(100, [.5:.01:.75],'k')
axis([xs 0 1])
% if k==1,
    ylab=ylabel([{'$\, \, \, \, C_t$'}; {'($\mu$M)'}]);
    set(ylab,...
        'Rotation',0,...
        'HorizontalAlignment','right',...
        'verticalalignment','middle',...
        'color','k',...
        'fontsize',yfs,...
        'Interpreter','latex')
% end
set(gca,'YTick',[0 0.5 1],'YTickLabel',[{round(cmin*100)/100}; {''}; {round(cmax*100)/100}])
set(gca,'XTick',[])

%spikes
subplot(3,1,3), hold on, %title(num2str(sum(R.n)))
stem(Sim.tvec,R.n,'Marker','none','Color',gray,'LineWidth',sw)
BarVar=M.nbar+M.nvar;
BarVar(BarVar>1)=1;
stem(Sim.tvec,BarVar,'Marker','none','Color',ccol(2,:),'LineWidth',sw)
stem(Sim.tvec,M.nbar,'Marker','none','Color',col(2,:),'LineWidth',sw)
axis([xs 0 1])
set(gca,'YTick',[0 0.5 1],'YTickLabel',[{'0'}; {''}; {'1'}])
% if k==1,
    ylab=ylabel([{'$\, \,  n_t$'}; {'($\#$)'}]);
    set(ylab,...
        'Rotation',0,...
        'HorizontalAlignment','right',...
        'verticalalignment','middle',...
        'color','k',...
        'fontsize',yfs,...
        'Interpreter','latex')
% else
%     set(gca,'YTickLabel',[])
% end
xlab=xlabel('Time (sec)');
set(xlab,'fontsize',xfs);

% print to (color) eps
fig=figure(5);
wh=[7 3];   %width and height
set(fig,'PaperPosition',[0 11-wh(2) wh]);
print -depsc C:\D\Research\liam\SMC_EM_GLM\satur