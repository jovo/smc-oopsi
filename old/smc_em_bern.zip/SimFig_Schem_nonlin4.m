% this file sets the parameters and does the simulation for making the
% schematic fig.  stimulus is a sinusoid. It generates the following:
%
% Sim:  simulation parameters
% P:    parameters of "real" neuron
% R:    "real" neuron data     
% S:    simulation states      
% M:    moments                
% fig:  a schematic figure

%% start function
clear; clc;

[Sim P] = InitializeStuff;

% set figure specific parameters
Sim.Nsec    = 0.65;                     %# of sec
Sim.T       = round(Sim.Nsec/Sim.dt);   %total # of steps (round deals with numerical error)
rem         = mod(Sim.T,Sim.freq);      %remainder
if rem~=0
    Sim.T=Sim.T-rem;                    %fix number of steps
end
Sim.T_o     = round(Sim.T/Sim.freq);    %number of observations (round deals with numerical error)
Sim.tvec    = Sim.dt:Sim.dt:Sim.Nsec-Sim.dt*rem;%time vector
Sim.N       = 250;
Sim.M       = 1;

% generate stimulus
sin_init    = -2.2*pi;
Sim.StimDim = 5;
Sim.x       = .02*rand(Sim.StimDim,Sim.T);
Sim.x       = Sim.x.*(25*repmat(sin(linspace(sin_init,sin_init+4*pi,Sim.T)),Sim.StimDim,1));

% linear filter
P.k         = ones(Sim.StimDim,1);%linear kernel
P.omega     = -3;               %jump size for h after spike
P.tau_h     = .01;                %decay rate for spike history terms

% get "real" data
kx        = P.k'*Sim.x;                                 %external input to neuron
epsilon_c = P.sigma_c*sqrt(Sim.dt)*randn(1,Sim.T);      %generate noise on calcium
U_sampl   = rand(1,Sim.T);                              %generate random number to use for sampling
R.C       = P.C_init*ones(1,Sim.T);                              %initialize calcium
R.p         = zeros(1,Sim.T);                       %extize p_t because it must be updated iteratively
R.n         = zeros(1,Sim.T);                       %extize n_t because it must be updated iteratively
spt         = [24 89];                  %forced spike times
R.n(spt)    = 1;                        %force spikes
R.h         = zeros(Sim.M,Sim.T);                   %extize spike history because it must be updated iteratively
R.y         = zeros(1,Sim.T);
epsilon_h = repmat(P.sigma_h*sqrt(Sim.dt),1,Sim.T).*randn(Sim.M,Sim.T); %generate noise on spike history
for t=2:Sim.T                                       %update states
    R.h(:,t)= (1-Sim.dt./P.tau_h).*R.h(:,t-1)+R.n(t-1) + epsilon_h(:,t);%update h terms
    R.y(t)=kx(t)+P.omega'*R.h(:,t);                    %generate operand for rate function
    R.p(t)=1-exp(-exp(R.y(t))*Sim.dt);                 %generate rate
end %time loop

epsilon_c   = P.sigma_c*sqrt(Sim.dt)*randn(1,Sim.T);%generate noise on calcium
for t=2:Sim.T                           %update calcium
    R.C(t)  = (1-P.a)*R.C(t-1) + P.A*R.n(t) + P.a*P.C_0 + epsilon_c(t);
end
F_mu        = P.alpha*Hill_v1(P,R.C)+P.beta;        %compute E[F_t]
F_var       = P.gamma*Hill_v1(P,R.C)+P.zeta;    %compute V[F_t]
R.F         = F_mu+sqrt(F_var).*randn(1,Sim.T);%add noise to observations
R.F(R.F<0)  = eps;                      %observations must be non-negative

% do EM recursion
[S M]   = smc_em_bern_FoBaMo_v5(Sim,R,P);
fprintf('\n')

save('schem_data')
%% make a fig
schem_fig2