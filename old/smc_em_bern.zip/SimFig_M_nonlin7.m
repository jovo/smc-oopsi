%%
clear, clc
gray    = [0.75 0.75 0.75];
yfs     = 14;
tfs     = 18;

%%
load Rate_params
figure(8), clf, hold on
b       = .05;
h       = .3;
siz=size(E);
for nn=1:2:siz(1)
    clear kvec theta
    if nn==5
        for kk=1:2
            kvec(kk,:)=E(nn,kk).k;
        end
    else
        for kk=1:siz(2)
            kvec(kk,:)=E(nn,kk).k;
        end
    end
    meankvec=mean(kvec);
    stdkvec=sqrt(var(kvec));
    subplot(121), hold on
    title('Linear Filter','fontsize',tfs)
    %subplot('Position', [.1 b+h*(nn-1) .43 h]), hold on
    o=2.5;
    plot([0:6],nn*o*ones(7,1)+3.2,'k')                                         %plot a line dividing calcium and spikes
    plot(P.k+nn*o,'linewidth',2,'color',gray)
    errorbar([1:5],meankvec+nn*o,stdkvec,'color','k','linewidth',2)
    set(gca,'XTick',[1:Sim.StimDim])
    xlabel('Dimension')%$k$','Interpreter','latex')
    %     axis([.9 nn+Sim.StimDim+.1 min(min(P.k),min(meankvec-stdkvec)) max(max(P.k),max(meankvec-stdkvec))])
    set(gca,'YTick',[3 8 13],'YTickLabel',[50 200 800],'fontsize',yfs)
    ylabel('Number of Spikes')
    axis([.9 Sim.StimDim+.1 0 nn*o+3])
    % ylab=ylabel({nSpikes(nn);'Spikes'});
    %     set(ylab,'Rotation',0,...
    %         'HorizontalAlignment','right',...
    %         'verticalalignment','middle',...
    %         'fontsize',yfs)
end

load Ca_params2
params=[P.tau_c; P.A; P.C_0; P.sigma_c];
subplot(122), cla, hold on
title('Calcium Parameters','fontsize',tfs)
nn=1;
for kk=1:siz(2)
    ca_est(kk,1)=E(nn,kk).tau_c;
    ca_est(kk,2)=E(nn,kk).A;
    ca_est(kk,3)=E(nn,kk).C_0;
    ca_est(kk,4)=E(nn,kk).sigma_c;
end
meanca_est=mean(ca_est);
stdca_est=sqrt(var(ca_est));
plot(params,'o','linewidth',2,'color',gray)
errorbar(meanca_est,stdca_est,'+','markersize',7,'color','k','linewidth',2)
% [hx,hy] = format_ticks(gca,{'$\tau_c$','$A$','[Ca$^{2+}]_0$','$\sigma_c$'},[],[1,2,3,4],'FontSize',16);
[hx,hy] = format_ticks(gca,...
    {'$\tau_c$','$A$','[Ca$^{2+}]_0$','$\sigma_c$'},...
    '',[1,2,3,4],[],0,45,[],...
    'FontSize',16,'FontWeight','Bold');
set(gca,'YTick',[.25 .5],'fontsize',yfs)
ylabel('Magnitude','fontsize',yfs)
axis([.9 3.1 min(0,min(meanca_est-stdca_est)) max(max(params),max(meanca_est-stdca_est))+.1])

fig=figure(8);
bgr=[6 3];
set(fig,'PaperPosition',[0 11-bgr(2) bgr]);
print -depsc C:\D\Research\liam\SMC_EM_GLM\mstep3